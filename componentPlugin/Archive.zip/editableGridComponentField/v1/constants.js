export const LICENSE_KEY = "[TRIAL]_this_{AG_Charts_and_AG_Grid}_Enterprise_key_{AG-051680}_is_granted_for_evaluation_only___Use_in_production_is_not_permitted___Please_report_misuse_to_legal@ag-grid.com___For_help_with_purchasing_a_production_key_please_contact_info@ag-grid.com___You_are_granted_a_{Single_Application}_Developer_License_for_one_application_only___All_Front-End_JavaScript_developers_working_on_the_application_would_need_to_be_licensed___This_key_will_deactivate_on_{31 January 2024}____[v3]_[0102]_MTcwNjY1OTIwMDAwMA==28c721feb2e1886381b211053fd5ff49";

// STYLING CONSTANTS - needs to be first p sure
export const THEME_MAP = {
    bgColor: "--ag-background-color",

    fgColor: "--ag-foreground-color",

    dataColor: "--ag-data-color",

    headerBGColor: "--ag-header-background-color",
    headerFGColor: "--ag-header-foreground-color",
    headerIconColor: "--ag-icon-font-color",

    rangeSelectionBorderColor: "--ag-range-selection-border-color",
    rangeSelectionBGColor: "--ag-range-selection-background-color",
    rangeSelectionBorderStyle: "--ag-range-selection-border-style",

    activeColor: "--ag-active-color",

    fontFamily: "--ag-font-family",

    // potentially do diff levels to accept here: critical, none, solid 1px, etc.
    borders: "--ag-borders",
    borderColor: "--ag-border-color",
    
    // controlPanelBGColor: "--ag-control-panel-background-color",
    // gridSize: "--ag-grid-size",
    // rowHeight: "--ag-row-height", --> looks really bad
    // fontSize: "--ag-font-size", ==> also looks pretty not good
    // headerHeight: "--ag-header-height", --> doesn't change anything
}

// Column level styling - Cell class rules and map
export const booleanCellClassRules = {
    "cellStyle-green": (params) => params.value in ["Yes", 1, true],
    "cellStyle-red": (params) => params.value in ["No", 0, false, "", null],
    // make dynamic later
    "cellStyle-background":(params) => true
}

// not working when called from Appian :/
export const numRangeCellClassRules = params => {
    console.log(params);
    return params.value > 0? {color: '#33cc3344'} : {color: '#cc222244'};
};

export const CELL_CLASS_RULES_MAP = {
    "booleanCellClassRules": booleanCellClassRules,
    "numRangeCellClassRules": numRangeCellClassRules
}


// servlet constants

const BASE_URL =
  window.location != window.parent.location
    ? document.referrer
    : document.location.href;
export const LOGGED_IN_USER_SERVLET_REQUEST_URL = `${BASE_URL}suite/plugins/servlet/getloggedinuser`;
export const USER_INFO_SERVLET_REQUEST_URL = `${BASE_URL}suite/plugins/servlet/getuserinfo`;
export const GROUP_INFO_SERVLET_REQUEST_URL = `${BASE_URL}suite/plugins/servlet/getgroupinfo`;


export async function getUserInfo(userID, displayField) {
    let url = `${USER_INFO_SERVLET_REQUEST_URL}?userID=${encodeURIComponent(userID)}&displayField=${encodeURIComponent(displayField)}`;
    const response = await fetch(url, {
        credentials: 'include'
    });
    const result = await response.json();
    return result;
}

export async function getGroupInfo(groupID) {
    let url = `${GROUP_INFO_SERVLET_REQUEST_URL}?groupID=${encodeURIComponent(groupID)}`;
    const response = await fetch(url, {
        credentials: 'include'
    });
    const result = await response.json();
    console.log(result);
    
    return result;
}

export const SELECTED_CLASS = "selected";
export const ODD_ROW_CLASS = "odd";

