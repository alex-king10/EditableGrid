class GridComponent {

    // init grid component instance
    constructor(containerId, hotInstance, data, columnConfigs, gridOptions, changeObj) {
        this.containerId = containerId;
        this.hotInstance = null;
        this.data = data;
        this.columnConfigs = columnConfigs;
        this.gridOptions = gridOptions;
        this.changeObj = changeObj;
    }

    // initialize grid instance
    initGrid() {
        const container = document.getElementById(this.containerId);
        if (!container) {
            console.error('Grid container does not exist');
        }

        this.hotInstance = new Handsontable(container, {
            licenseKey: "non-commercial-and-evaluation",
          });
        
        // data, columnConfig, gridOptions
        this.hotInstance.updateSettings({
            data: this.data,
            columns: this.columnConfigs,
        });

        this.hotInstance.updateSettings(this.gridOptions);
    }

    initData(dataParam, relatedRecords) {
        // write this logic
    }



    // not sure if this function logic should go here?
    updateData(changeObj) {
        let currRowIdx;
        let currChangeItem;

        if (this.data != null && this.data.length != 0) {
            if (Object.keys(changeObj).length == 0) {
                // no updates to make to data var
                return this.data;
            } else {
                for (let i = 0; i < Object.keys(changeObj).length; i++) {
                    currsRowIdx = Object.keys(changeObj)[i];
                    currChangeItem = Object.values(changeObj)[i];
                    // update row in data var with value from changeObj
                    this.data[currRowIdx] = Object.assign(dataMap[currRowIdx], currChangeItem);
                }
            }
        }
    }

}

export default GridComponent;