
export function safeHtmlRenderer(instance, td, row, col, prop, value, cellProperties) {
    // WARNING: Be sure you only allow certain HTML tags to avoid XSS threats.
    // Sanitize the "value" before passing it to the innerHTML property.
    td.innerHTML = value;
}


export function coverRenderer(instance, td, row, col, prop, value, cellProperties) {
    const img = document.createElement('img');
  
    img.src = value;
  
    img.addEventListener('mousedown', (event) => {
      event.preventDefault();
    });
  
    td.innerText = '';
    td.appendChild(img);
  
    return td;
  }