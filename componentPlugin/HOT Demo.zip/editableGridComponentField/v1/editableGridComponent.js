// import { data } from "./constants.js";
import { safeHtmlRenderer } from "./customRenderers.js";


// GLOBAL VAR
let data = [];
let columnHeaderData = [];
let changeObj = {};

// CUSTOM RENDERERS
function coverRenderer(instance, td, row, col, prop, value, cellProperties) {
  // console.log([instance, td, row, col, prop, value, cellProperties]);
  const img = document.createElement('img');

  img.src = value;

  img.addEventListener('mousedown', (event) => {
    event.preventDefault();
  });

  td.innerText = '';
  td.appendChild(img);

  return td;
}

Handsontable.renderers.registerRenderer('my.coverRenderer', coverRenderer);


function fileRenderer(instance, td, row, col, prop, value, cellProperties) {
  console.log([instance, td, row, col, prop, value, cellProperties]);
  const fileViewer = document.createElement('div');
  fileViewer.classList.add('file-viewer'); // Optional: Add a class for styling
  
  // Assuming value contains the file URL
  const fileUrl = value;

  fileViewer.innerText = 'Click to view file'; // Placeholder text for file viewer
  
  fileViewer.addEventListener('click', () => {
    // Replace this with your file viewer logic
    // For example, open a modal or display the file content in a different way
    alert('Opening file viewer for: ' + fileUrl);
  });

  td.innerText = '';
  td.appendChild(fileViewer);

  return td;
}

Handsontable.renderers.registerRenderer('my.fileRenderer', fileRenderer);


// INSTANTIATE GRID W/ DATA AND COLUMN
function setGridData(rowsParam)
{
  // if (rowsParam == null)
  // {
  //   return data;
  // }
  data = [];
  let currRow = [];

  if (rowsParam != null)
  {
    for (let i = 0; i < rowsParam.length; i++)
    {
      if ((Object.keys(changeObj).length != 0 && changeObj[i] != undefined)) {
        currRow = changeObj[i];
      } else {
        currRow = Object.values(rowsParam[i]);
      }

      // currRow = Object.values(rowsParam[i]);
      data.push(currRow);
    }
    // reset changeObj?
    // changeObj = {};
  }
  
  console.log(data);
  return data;
}

function setColumnData(colHeaderParam, dataParam)
{
  columnHeaderData = [];

  if (colHeaderParam != null)
  {
    console.log("colHeaderParam");
    console.log(colHeaderParam);
    // columnHeaderData = colHeaderParam;
    return colHeaderParam;
  } else {
    if (dataParam != null)
    {
      columnHeaderData = Object.keys(dataParam[0]);
      console.log("Here");
      console.log(columnHeaderData);

    }
  }

  console.log(columnHeaderData);

  return columnHeaderData;

}

function setColMetaData(columnConfigParam)
{
  // columnConfigParam?.forEach((colConfig) => {
  //   console.log(colConfig);

  // });
  return columnConfigParam;
}

// HANDLE CHANGES IN DATA
function onChange(cellMeta, newValue, source)
{

  if (cellMeta != null)
  {
    
    let dataItem = data[cellMeta.row];
    let fieldName = columnHeaderData[cellMeta.visualCol];

    console.log(dataItem);
    changeObj[cellMeta.row] = dataItem;

  }

}

let hotGrid;
try {
  console.log("Init started.");

// init grid
  const container = document.getElementById("myGrid");
  hotGrid = new Handsontable(container, {
    licenseKey: "non-commercial-and-evaluation",
    // Style Param - Customizable Values
  });
} catch (error) {
  console.error(`An error occurred ${error}`);
}
console.log("Init finished.");


Appian.Component.onNewValue(newValues => {

  console.log("Update started.");

  // retrieve component parameters
  let dataParam = newValues.rows;
  let colHeaderParam = newValues.headerCells;
  let configParam = newValues.columnConfigs;
  let darkModeParam = newValues.darkMode;
  let gridOptionsParam = newValues.gridOptions;
  // let styleParam = newValues.style;
  let changeDataParam = newValues.changeData;

  console.log("newValues");
  console.log(newValues);

  // create an external HyperFormula instance
  // const hyperformulaInstance = HyperFormula.buildEmpty({
  //   // initialize it with the `'internal-use-in-handsontable'` license key
  //   licenseKey: 'internal-use-in-handsontable',
  // });

  try {

    if (hotGrid == null || hotGrid == undefined) {
      console.error(`Hot grid null or undefined: ${hotGrid}`);
    }

    // update grid
    // hotGrid.updateData(setGridData(dataParam));

    hotGrid.updateSettings({
      data: setGridData(dataParam),
      // formulas: {
      //   engine: HyperFormula,
      // },
      colHeaders: setColumnData(colHeaderParam, dataParam),
      columns: setColMetaData(configParam),
      multiColumnSorting: true,
      dropdownMenu: true,
      hiddenColumns: {
        indicators: true
      },
      contextMenu: true,
      allowInsertColumn: false,
      filters: true,
      allowInsertRow: true,
      manualColumnMove: true,
      manualColumnResize: true,
      rowHeaders: false,
      manualRowMove: false,
      rowHeights: 40,
      className: "htMiddle",
    });

    if (gridOptionsParam != null)
    {
      console.log("gridOptionsParam");
      console.log(gridOptionsParam);
      hotGrid.updateSettings(
        gridOptionsParam
      );
    } else {
      console.log("gridOptions param is null");
    }

    console.log("Update ended.");

    console.log("Forcing a render");
    hotGrid.render();


    // EVENT HANDLING
    hotGrid.addHook('afterChange', (changes, [source]) => {

      console.log([source]);
  
      // call handle change function
      changes?.forEach(([row, prop, oldValue, newValue]) => {
  
        if (newValue != oldValue)
        {
          let cellMeta = hotGrid.getCellMeta(row, prop);
          onChange(cellMeta, newValue, [source]);
          console.log(changeObj);
          Appian.Component.saveValue("changeData", changeObj);
        }
  
      });
  
    });

    // Function to call after a new row has been created
    hotGrid.addHook('afterCreateRow', (row, amount) => {
      console.log(`${amount} row(s) were created, starting at index ${row}`);
      // need to specially handle this edit - find last PK and increment?
    });

    hotGrid.addHook('afterColumnMove', (movedColumns, finalIndex, dropIndex, movePossible, orderChanged) => {
      console.log(movedColumns, finalIndex, dropIndex, movePossible, orderChanged);
      // let cellMeta = hotGrid.getCellMeta(1,1);
      // console.log(cellMeta);
    });

    hotGrid.addHook('afterColumnSort', (currentSortConfig, destinationSortConfigs) => {
      console.log(currentSortConfig);
      console.log(destinationSortConfigs);
    });


  } catch (error) {
    console.error("An error occured creating the grid:", error);
  }


});

